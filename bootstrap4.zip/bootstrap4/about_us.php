<?php
    include_once "template_header.php";
?>
<div class="row">
    <h1 class='display-4'>About Us</h1>
</div>
<div class="row">
    <img class='img-fluid' src="images/learning.jpg">
</div>

<?php
    include_once "template_footer.php";
?>