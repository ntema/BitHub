<link rel="stylesheet" href="css/bootstrap.min.css">
<?php

    $str = "<h3>I love php</h3>";

    $str1 = "<div class='row'>
                <div class='col-lg-4'>$str</div>
                <div class='col-lg-4'>$str</div>
                <div class='col-lg-4'>$str</div>   
            </div>";
    echo $str1;
?>